# YieldnYarn UML assignment

Submit these **two separate native StarUML project files**:

- `YieldnYarn_Component_Diagram.mdj`
- `YieldnYarn_Deployment_Diagram.mdj`

Each project contains exactly one diagram of the appropriate UML type. Components, interfaces, dependencies, nodes, artifacts and communication paths are editable model elements. The PNG files are previews, not substitutes for the StarUML projects.

## Open in StarUML

1. Choose **File > Open** (Ctrl+O), and select a `.mdj` file.
2. If the canvas does not appear automatically, expand the model in Model Explorer and double-click `YieldnYarn - Component Diagram` or `YieldnYarn - Deployment Diagram`.
3. Use **View > Zoom > Fit to Window** if necessary. Open the second project separately when reviewing the other diagram.

## What the diagrams show

The **Component Diagram** shows the Next.js web application, Kotlin seller application, offline persistence, Django marketplace modules, FastAPI compute modules, three provided API interfaces, shared PostgreSQL persistence, evidence storage, Agmarknet and optional Firebase messaging. Nested Django and FastAPI components are logical modules within their containing services, not separate microservices. Interfaces use the standard rectangular `«interface»` notation for legibility. Dashed open arrows show dependencies; dashed lines with hollow triangles show interface realization by the provider.

The **Deployment Diagram** shows the **Azure deployment design configured by `infra/azure/main.bicep`**, rather than asserting that a live Azure deployment exists. It includes client devices and runtimes, the Azure Container Apps environment and three application containers, PostgreSQL Flexible Server, private Blob Storage, application artifacts, model checkpoints and protocol-labelled communication paths. Artifacts nested inside a node are deployed or stored there. TLS ingress uses port 443 and maps to application target ports 3000, 8000 and 8001. Both backends connect to PostgreSQL over TLS on port 5432. Browser and Android clients can call public pricing directly; Django supplies the internal token for grading and matching.

Firebase push is optional, requires separate credentials, and is not provisioned by the Azure template. The local Docker Compose alternative uses PostgreSQL/PostGIS and a shared media volume; the deployment diagram consistently uses the Azure configuration instead of mixing the two environments.

## References and project evidence

- [GeeksforGeeks: Component Based Diagram](https://www.geeksforgeeks.org/software-engineering/component-based-diagram/) — component, interface and dependency notation.
- [GeeksforGeeks: Deployment Diagram](https://www.geeksforgeeks.org/system-design/deployment-diagram-unified-modeling-languageuml/) — nodes, artifacts and communication paths.
- Repository evidence: `README.md`, `docker-compose.yml`, `infra/azure/main.bicep`, the three Dockerfiles, `web-app/lib/api.ts`, Django catalog/order views and notifications integration, and Android data/sync modules. Current source was preferred over older README notes describing grading and Firebase as stubs.
- [StarUML: Opening projects](https://docs.staruml.io/user-guide/managing-project).

## Verification

Generated and rendered with the UML model/view and serialization code from the official [StarUML Metadata-JSON library](https://github.com/staruml/metadata-json), using the official [StarUML samples](https://github.com/staruml/staruml-samples) as a format reference. Both models pass that library's model validator with zero reported violations. IDs and references were checked for uniqueness and resolution; each file contains one correctly typed diagram. Previews were visually inspected. The StarUML desktop application was unavailable, so desktop opening was not separately tested.

## Readability revision

Both files now use black text and outlines on white backgrounds, with no colour fills or shadows. Ordinary text and connector labels use Arial 22; subtitles use 24; diagram titles use bold 36. The layouts have more vertical space, shorter captions, wider client runtime nodes, and rerouted connectors. The PNG previews were regenerated from the final model geometry and inspected for text clipping, crowded labels, and connectors crossing text or artifacts. These are rendered previews, not screenshots of the StarUML application, which is not installed here. At a zoom level that shrinks the entire large diagram into a small window, text will naturally shrink too; use 100% zoom for the intended text size.
